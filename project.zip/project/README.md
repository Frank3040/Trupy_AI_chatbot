#### start project

```
cd project

npx vite
```